---
description: How to install the ligatures
---

# Installation instructions

