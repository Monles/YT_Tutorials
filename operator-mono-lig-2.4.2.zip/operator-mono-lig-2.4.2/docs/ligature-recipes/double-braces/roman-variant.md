---
description: How to create the Roman variant of the double-brace ligature
---

# Roman variant

{% hint style="info" %}

{% endhint %}

1. Add the `braceleft` component twice, or `braceright` component twice.
2. Create a guide \(Right-click -&gt; Add Guide\)
3. Set the settings on the guide as so:

