# Ensuring ligatures work at small sizes

After creating each ligature, you going to need to make sure it works at very small sizes. Ensure the brace works at very small sizes by looking at it when its very small, by dragging up from the bottom of the editor. This need to be done because as [ScreenSmart fonts are guaranteed to work at a minimum of 9px](https://www.typography.com/fonts/operator/how-to-use#setting_text_and_headlines):

![](../.gitbook/assets/image%20%288%29.png)

